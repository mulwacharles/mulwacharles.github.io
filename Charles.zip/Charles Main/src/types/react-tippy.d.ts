import 'react-tippy';
declare module 'react-tippy' {
  export interface TooltipProps {
    children?: React.ReactNode;
  }
}
